#pragma once
#include "../Class/Camera/e2v_EV71YC1CCL4005BA0/E2VCamera.h"
#include <thread>

class Worker
{
public:
	Worker(E2VBuffer *_e2vbuffer);
	~Worker();
private:
	E2VBuffer *p_e2vbuffer = NULL;


	//ֱ�Ӷ�ȡN��ͼƬ
	void work();
	static const int frameCountsOut = 12000;
	//��ѭ��������ȡ��ͼƬ
	cv::Mat getPhoto(int startFrame, int endFrame);
};