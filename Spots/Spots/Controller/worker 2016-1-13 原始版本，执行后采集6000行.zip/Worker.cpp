#include "Worker.h"


Worker::Worker(E2VBuffer *_e2vbuffer)
{
	p_e2vbuffer = _e2vbuffer;

	//std::thread t_workThread(std::mem_fn(&Worker::work), this);
	//t_workThread.detach();
	work();
}


Worker::~Worker()
{
}


void Worker::work()
{
	int startFrame = p_e2vbuffer->WriteIndex;
	//������ȴ�һ��ʱ�䣬ש�ߵ���������


	cv::Mat image = getPhoto(startFrame, 6000);
	return;
}
//length < 
//ȡͼ��Χ startFrame �� endFrame������startFrame��endFrame����
cv::Mat Worker::getPhoto(int startFrame, int length)
{
	//TODO::����һû����
	int width = p_e2vbuffer->Buffer.cols;

	int endFrame = startFrame + 6000 - 1;
	if (endFrame >= E2VBuffer::BufferLength)
	{
		endFrame = endFrame - E2VBuffer::BufferLength;
	}




	//wait capture end
	
	while (true)
	{
		int now = p_e2vbuffer->WriteIndex;
		if (endFrame > startFrame  && now >= endFrame)
			break;
		else if (startFrame > endFrame && now >= endFrame && now < length)
			break;
		Sleep(1);
	}




	//��ȡͼ��
	if (endFrame > startFrame)
	{
		cv::Mat result = p_e2vbuffer->Buffer(cv::Rect(0, startFrame, width, length)).clone();
		result *= 3;
		return result;
	}
	else
	{
		cv::Mat result(6000, width, p_e2vbuffer->Buffer.channels() == 3 ? CV_8UC3 : CV_8U, cv::Scalar(0, 0, 0));
		cv::Mat roi1 = result(cv::Rect(0, 0, width, E2VBuffer::BufferLength - startFrame));
		cv::Mat roi2 = result(cv::Rect(0, E2VBuffer::BufferLength - startFrame, width, endFrame + 1));

		p_e2vbuffer->Buffer(cv::Rect(0, startFrame, width, E2VBuffer::BufferLength - startFrame)).copyTo(roi1);	//debug 2΢�� release 1.5΢��
		p_e2vbuffer->Buffer(cv::Rect(0, 0, width, endFrame + 1)).copyTo(roi2);


		result *= 3;
		return result;
	}
}
